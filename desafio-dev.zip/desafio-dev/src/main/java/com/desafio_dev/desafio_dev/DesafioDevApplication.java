package com.desafio_dev.desafio_dev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesafioDevApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesafioDevApplication.class, args);
	}

}
