package com.desafio_dev.desafio_dev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesafioDevApplicationTests {

	@Test
	void contextLoads() {
	}

}
